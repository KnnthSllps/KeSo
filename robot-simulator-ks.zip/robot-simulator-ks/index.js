var readline = require('readline');

var Commands = require('./lib/commands');
var TableTop = require('./lib/tabletop');

var commands = new Commands();
var tableTop = new TableTop(5,5);


var inputNum = 0;
var toy = {x:0, y:0, face:""};
var directions = ["NORTH", "EAST", "SOUTH", "WEST"]; //clock-wise


var rd = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: false
});

rd.setPrompt("\n\n============ Welcome to Robot Simulator ============ \n\n" + "Please type your command line by line, or 'exit' to exit > \n" );
rd.prompt(false);

rd.on('line', async function(line) {
    if (!line) return;
    let command = await commands.validateFirstCommand(line, inputNum);

    if(!command.indicator){
        if(command.result == "EXIT"){
            rd.close();
        } else {
            return console.log("You need to place coordinates first (X,Y,Face Direction)");    
        }
    } else {
        inputNum += 1;
        let switchCommand = await commands.switchCommand(command.result, toy, directions, tableTop);
        if(switchCommand.message === "WRONG") {
            inputNum = inputNum == 1 ? 1 : inputNum - 1;
            return console.log("Wrong input: " + line);
        } else if(switchCommand.message === "REPORT") {
            return console.log(switchCommand.output);
        } else {
            toy = switchCommand.result;
            return;
        }
    }
})
.on('close', function() {
    console.log('\n======================= END =======================');
    process.exit(0);
});
