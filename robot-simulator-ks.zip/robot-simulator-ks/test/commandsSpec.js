var expect = require('chai').expect;
var Commands = require('../lib/commands');
var TableTop = require('../lib/tabletop')

describe('Commands', function() {
    var commands;
    var inputNum;
    var toy;
    var directions;
    var tabletop;

  beforeEach(function() {
    commands = new Commands();
    tabletop = new TableTop(5,5);
    inputNum = 0;
    toy = {x:0, y:0, face:""};
    directions = ["NORTH", "EAST", "SOUTH", "WEST"]; //clock-wise
  });

  it('should place a robot correctly on valid point on the table', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,0,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:0, y:0, face: 'NORTH' });
  });

  it('should ignore any place instruction that is off the board', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,1,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("Place 6,1,West", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:0, y:1, face: 'NORTH' });
    expect(switchResult.message).to.equal("WRONG");
  });

  it('should correctly replace the robot if asked to', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,1,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("Place 2,2,SOUTH", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:2, y:2, face: 'SOUTH' });
    expect(switchResult.message).to.equal(null);
  });

  it('should correctly turn when issued left command', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,1,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("LEFT", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:0, y:1, face: 'WEST' });
    expect(switchResult.message).to.equal(null);
  });

  it('should correctly turn when issued right command', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,1,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("RIGHT", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:0, y:1, face: 'EAST' });
    expect(switchResult.message).to.equal(null);
  });

  it('should correctly move when issued a move command', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 0,1,North", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("MOVE", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:0, y:2, face: 'NORTH' });
    expect(switchResult.message).to.equal(null);
  });

  it('should report it\'s current position & direction when issued a report instruction', function() {
    inputNum = 0;
    let result = commands.validateFirstCommand("Place 1,2,EAST", inputNum);
    let switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    inputNum = 1;
    result = commands.validateFirstCommand("MOVE", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    result = commands.validateFirstCommand("MOVE", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    result = commands.validateFirstCommand("LEFT", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    result = commands.validateFirstCommand("MOVE", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    result = commands.validateFirstCommand("REPORT", inputNum);
    switchResult = commands.switchCommand(result.result, toy, directions, tabletop);
    
    expect(result.indicator).to.be.true;
    expect(switchResult.result).to.deep.equal({ x:3, y:3, face: 'NORTH' });
    expect(switchResult.message).to.equal("REPORT");
    expect(switchResult.output).to.equal("Output: 3,3,NORTH");
  });
});