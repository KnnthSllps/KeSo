# Robot simulator

This is a robot simulator wrtten in Node.js

## How to use?
1. Open console and go to path of the robot simulator.
2. Type `npm install` or `npm i` in the terminal.
3. To start the simulator type `node index.js` in the terminal and welcome text will be displayed.
4. Now you are free to play.

## Instruction

The simulator only accepts one command per line. The commands available are:

- **PLACE X, Y, DIRECTION (PLACE 0,1,NORTH):** Place the robot on the table.
- **MOVE:** Move the robot one unit in the direction it is facing
- **LEFT:** Turn the robot left
- **RIGHT:** Turn the robot right
- **REPORT:** Report the current position and direction of the robot (0,0,NORTH)

It is required that the first command to the robot is a PLACE command, after that, any sequence of commands may be issued, in any order, including another PLACE command.
The table is a 5x5 dimension, and any command that would result in the robot being off the table *will be ignored*.
*NOTE* -- table dimension can be modified depends on the setup in tabletop.


## Tests
Run `npm test` in the terminal.